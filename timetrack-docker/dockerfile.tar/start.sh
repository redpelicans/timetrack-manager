#!/bin/bash

NODE_ENV=production DEBUG=timetrack:* node server/lib/main.js
